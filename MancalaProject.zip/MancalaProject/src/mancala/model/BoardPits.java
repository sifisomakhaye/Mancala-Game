package mancala.model;

import java.util.Optional;


// BoardPits class is responsible for small pits with stones
public abstract class BoardPits {

    protected int stones;

    private BoardPits next;

    protected final PlayerNumber currentPlayer;

    BoardPits(PlayerNumber currentPlayer, int stones) {
        this.currentPlayer = currentPlayer;
        this.stones = stones;
    }

    public Integer count() {
        return stones;
    }

    public BoardPits next() {
        return next;
    }

    public BoardPits setNext(BoardPits next) {
        this.next = next;
        return next;
    }

    public void sow() {
        this.stones++;
    }

    public PlayerNumber getCurrentPlayer() {
        return currentPlayer;
    }

    abstract boolean isSowable(PlayerNumber player);

    public boolean isEmpty() {
        return this.stones == 0;
    }

    public Optional<Pit> getOpposite() {
        return Optional.empty();
    }

    public Integer capture() {
        if (this.getOpposite().isEmpty()) {
            return 0;
        }
        return this.getOpposite().get().take();
    }

    public Integer take() {
        return 0;
    }

}
