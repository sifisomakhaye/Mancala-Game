package mancala.model;

// Game class comes with rules of the game
public class Game {

    public enum Status {

        Active,

        Draw,

        PLAYER1_WIN,

        PLAYER2_WIN

    }

    public record Result(Status status, PlayerNumber next, Board board) {}

    private Board board;

    private Player player;

    private Status status;

    public static Game create(Board board) {
        Game game = new Game();
        game.board = board;
        game.player = board.getPlayers().player1();
        game.status = Status.Active;
        return game;
    }

    public Result move(PlayerNumber num, int pit) {
        if (!player.num().equals(num)) {
            throw new IllegalStateException(String.format("Player %s cannot take their turn yet", num));
        }
        BoardPits landed = player.turn(pit);
        if (player.complete()) {
            otherPlayer().finish();
            status = declareWinner();
        }
        player = nextPlayer(landed);
        return new Result(status, player.num(), board);
    }

    private Status declareWinner() {
        Board.Players players = board.getPlayers();
        int score1 = players.player1().score();
        int score2 = players.player2().score();
        if (score1 > score2) {
            return Status.PLAYER1_WIN;
        }
        if (score2 > score1) {
            return Status.PLAYER2_WIN;
        }
        return Status.Draw;
    }

    public Player nextPlayer(BoardPits landed) {
        if (landed.equals(player.store())) {
            return player;
        }
        return otherPlayer();
    }

    private Player otherPlayer() {
        Board.Players players = board.getPlayers();
        return switch (player.num()) {
            case ONE -> players.player2();
            case TWO -> players.player1();
        };
    }

    public Player getActivePlayer() {
        return player;
    }

}
