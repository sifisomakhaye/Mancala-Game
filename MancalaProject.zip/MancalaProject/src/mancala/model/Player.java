package mancala.model;

import java.util.List;

// Player class determines which player plays next depending on conditions
public record Player(PlayerNumber num, List<Pit> pits, Store store) {

    public BoardPits turn(int pitNum) {
        Pit pit = getPit(pitNum);
        checkHasStones(pit);
        BoardPits smallPit = takeTurn(pit);
        if (shouldCaptureOpposite(smallPit)) {
            store.sow(smallPit.take());
            store.sow(smallPit.capture());
        }
        return smallPit;
    }

    public boolean complete() {
        return pits.stream().allMatch(Pit::isEmpty);
    }

    public void finish() {
        for (Pit pit: pits) {
            store.sow(pit.take());
        }
    }

    public int score() {
        return store.count();
    }

    private boolean shouldCaptureOpposite(BoardPits pit) {
        return pit.count() == 1 && pit.getOpposite().isPresent();
    }

    private void checkHasStones(Pit pit) {
        if (pit.isEmpty()) {
            throw new IllegalArgumentException("House must have stones to take turn");
        }
    }

    private BoardPits takeTurn(Pit pit) {
        Integer stones = pit.take();
        BoardPits smallPit = pit;
        while (stones > 0) {
            smallPit = smallPit.next();
            if (smallPit.isSowable(num)) {
                stones--;
                smallPit.sow();
            };
        }
        return smallPit;
    }

    private Pit getPit(int pitNum) {
        if (pitNum < 1 || pitNum > pits.size()) {
            throw new IllegalArgumentException("House number must be between 1 and " + pits.size());
        }
        return this.pits.get(pitNum - 1);
    }

}
