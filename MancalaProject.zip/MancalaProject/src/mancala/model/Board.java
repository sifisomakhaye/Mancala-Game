package mancala.model;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Stream;

import static mancala.model.PlayerNumber.ONE;
import static mancala.model.PlayerNumber.TWO;

// Board class is responsible for the entire board
public class Board {

    public record Players(Player player1, Player player2) {}

    private List<Pit> pit;

    private List<Store> stores;

    private Players players;

    private Board() {}

    public static Board create() {
        return create(6, 6);
    }    
    // This instantiate the new object
    public static Board from(List<Integer> player1Pits, int p1Store, List<Integer> player2Pits, 
    		int p2Store) {
        LinkedList<Pit> pitOne = buildPits(ONE, player1Pits);
        LinkedList<Pit> pitTwo = buildPits(TWO, player2Pits);
        mutuallyOpposite(pitOne, pitTwo);

        Store storeOne = new Store(ONE, p1Store);
        Store storeTwo = new Store(TWO, p2Store);

        circular(pitOne, storeOne, pitTwo, storeTwo);

        Player player1 = new Player(ONE, pitOne, storeOne);
        Player player2 = new Player(TWO, pitTwo, storeTwo);

        Board board = new Board();
        board.pit = new ArrayList<>(pitOne);
        board.pit.addAll(pitTwo);
        board.stores = List.of(storeOne, storeTwo);
        board.players = new Players(player1, player2);

        return board;
    }
    
    // This method guides the stones in the pit not to be more than they should
    public static Board create(int numberOfStones, int length) {
        var stones = Stream.generate(() -> numberOfStones).limit(length).toList();
        return from(stones, 0, stones, 0);
    }

    private static LinkedList<Pit> buildPits(PlayerNumber playerNumber, List<Integer> stones) {
        LinkedList<Pit> pits = new LinkedList<>();
        pits.addLast(new Pit(playerNumber, stones.get(0)));
        while (pits.size() < stones.size()) {
            Pit pit = new Pit(playerNumber, stones.get(pits.size()));
            pits.getLast().setNext(pit);
            pits.addLast(pit);
        }
        return pits;
    }

    private static void mutuallyOpposite(List<Pit> pitOne, List<Pit> pitTwo) {
        for (int i = 0; i< pitOne.size(); i++) {
            Pit one = pitOne.get(i);
            Pit two = pitTwo.get(pitTwo.size() - i - 1);
            one.setOpposite(two);
            two.setOpposite(one);
        }
    }

    private static void circular(LinkedList<Pit> pitOne, Store storeOne, LinkedList<Pit> pitTwo,
    		Store storeTwo) {
        pitOne.getLast().setNext(storeOne);
        storeOne.setNext(pitTwo.getFirst());
        pitTwo.getLast().setNext(storeTwo);
        storeTwo.setNext(pitOne.getFirst());
    }

    public List<Pit> getPits() {
        return pit;
    }

    public List<Store> getStores() {
        return stores;
    }

    public Players getPlayers() {
        return players;
    }
}
