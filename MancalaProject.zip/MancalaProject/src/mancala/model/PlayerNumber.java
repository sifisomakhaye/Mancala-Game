package mancala.model;

//This allows to pick whether its player1 or player2
public enum PlayerNumber {
    ONE,
    TWO
}