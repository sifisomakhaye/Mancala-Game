package mancala.model;

import java.util.Optional;

// Pit class is responsible for large pits with stones
public class Pit extends BoardPits {
	
	private Pit opposite;

    public Pit(PlayerNumber currentPlayer, int stones) {
        super(currentPlayer, stones);
    }

    @Override
    public Integer take() {
        int stones = this.stones;
        this.stones = 0;
        return stones;
    }

    @Override
    public Optional<Pit> getOpposite() {
        return Optional.ofNullable(opposite);
    }

    public void setOpposite(Pit opposite) {
        this.opposite = opposite;
    }

    boolean isSowable(PlayerNumber player) {
        return true;
    }

    @Override
    public String toString() {
        return "House{" +
                "stones = " + stones +
                ", Current Player= " + currentPlayer +
                '}';
    }

}
