package mancala.model;

// store class is responsible for storing stones in large pits 
public class Store extends BoardPits {

    public Store(PlayerNumber currentPlayer) {
        super(currentPlayer, 0);
    }

    Store(PlayerNumber currentPlayer, int stones) {
        super(currentPlayer, stones);
    }

    public void sow(int i) {
        stones += i;
    }

    boolean isSowable(PlayerNumber player) {
        return player.equals(currentPlayer);
    }

    @Override
    public String toString() {
        return "Store{" +
                "stones=" + stones +
                ", Current Player=" + currentPlayer +
                '}';
    }

}
