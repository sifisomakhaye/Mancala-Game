package mancala.tests;

import mancala.model.Pit;
import mancala.model.Store;
import org.junit.jupiter.api.Test;

import static mancala.model.PlayerNumber.ONE;
import static org.assertj.core.api.Assertions.assertThat;

public class TestPit {

    @Test
    public void shouldStoreStonesInPit() {
        Pit pit = new Pit(ONE, 6);
        assertThat(pit.count()).isEqualTo(6);
    }

    @Test
    public void storeShouldBeginEmpty() {
        Store largePit = new Store(ONE);
        assertThat(largePit.count()).isEqualTo(0);
    }

    @Test
    public void shouldPointToTheNextPit() {
        Pit a = new Pit(ONE, 6);
        Store b = new Store(ONE);
        Pit c = new Pit(ONE, 6);

        a.setNext(b);
        b.setNext(c);

        assertThat(a.next()).isEqualTo(b);
        assertThat(b.next()).isEqualTo(c);
    }

    @Test
    public void shouldBeAbleToTakeStonesFromPit() {
        Pit pit = new Pit(ONE, 4);
        assertThat(pit.count()).isEqualTo(4);

        Integer taken = pit.take();

        assertThat(taken).isEqualTo(4);
        assertThat(pit.count()).isEqualTo(0);
    }

    @Test
    public void shouldBeAbleToSowStonesInPit() {
        Pit pit = new Pit(ONE, 0);
        pit.sow();
        assertThat(pit.count()).isEqualTo(1);
    }

    @Test
    public void shouldBeAbleToSowStonesInStore() {
        Store store = new Store(ONE);
        store.sow();
        assertThat(store.count()).isEqualTo(1);
    }

    @Test
    public void shouldBeAbleToSowMultipleStonesInStore() {
        Store store = new Store(ONE);
        store.sow(4);
        assertThat(store.count()).isEqualTo(4);
    }

}
