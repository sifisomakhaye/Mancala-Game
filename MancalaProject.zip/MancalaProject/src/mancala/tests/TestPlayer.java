package mancala.tests;

import mancala.model.BoardPits;
import mancala.model.Pit;
import mancala.model.Player;
import mancala.model.Store;
import org.junit.jupiter.api.Test;

import java.util.List;

import static mancala.model.PlayerNumber.ONE;
import static mancala.model.PlayerNumber.TWO;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class TestPlayer {

    @Test
    void playerShouldSowStonesOnTurn() {
        Pit last = new Pit(ONE, 0);
        Pit middle = new Pit(ONE,0);
        Pit first = new Pit(ONE,2);
        Store end = new Store(ONE);

        first.setNext(middle).setNext(last).setNext(end);

        Player player = new Player(ONE, List.of(first, middle, last), end);
        BoardPits landed = player.turn(1);

        assertThat(landed).isEqualTo(last);
        assertThat(first.count()).isZero();
        assertThat(middle.count()).isEqualTo(1);
        assertThat(last.count()).isEqualTo(1);
    }

    @Test
    void playerCannotChooseEmptyPit() {
        assertThrows(IllegalArgumentException.class, () -> {
            Player player = new Player(ONE, List.of(new Pit(ONE, 0)), new Store(ONE));
            player.turn(1);
        });
    }

    @Test
    void playerCannotChoosePitBelowRange() {
        assertThrows(IllegalArgumentException.class, () -> {
            Player player = new Player(ONE, List.of(new Pit(ONE, 0)), new Store(ONE));
            player.turn(0);
        });
    }

    @Test
    void playerSkipsOpponentsStore() {
        Pit myPit = new Pit(ONE,3);
        Store myStore = new Store(ONE);
        Pit opponentPit = new Pit(TWO,0);
        Store opponentStore = new Store(TWO);

        myPit.setNext(myStore)
                .setNext(opponentPit)
                .setNext(opponentStore)
                .setNext(myPit);

        Player player = new Player(ONE, List.of(myPit), myStore);
        BoardPits landed = player.turn(1);

        assertThat(landed).isEqualTo(myPit);
        assertThat(myPit.count()).isEqualTo(1);
        assertThat(myStore.count()).isEqualTo(1);
        assertThat(opponentPit.count()).isEqualTo(1);
        assertThat(opponentStore.count()).isZero();
    }

}
