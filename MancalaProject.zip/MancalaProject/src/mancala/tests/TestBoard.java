package mancala.tests;

import mancala.model.*;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static mancala.model.PlayerNumber.ONE;
import static mancala.model.PlayerNumber.TWO;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

class TestBoard {

    @Test
    
    // Testing the board pits
    void boardShouldHaveTwelvePit() {
        Board board = Board.create();
        List<Pit> pits = board.getPits();
        Map<PlayerNumber, List<Pit>> sides = pits.stream().collect(Collectors.groupingBy(Pit::getCurrentPlayer));
        assertThat(sides.get(ONE).size()).isEqualTo(6);
        assertThat(sides.get(TWO).size()).isEqualTo(6);
    }

    @Test
    
    // testing the two large pits
    void boardShouldHaveTwoStores() {
        Board board = Board.create();
        List<Store> stores = board.getStores();
        Map<PlayerNumber, List<Store>> sides = stores.stream().collect(Collectors.groupingBy(Store::getCurrentPlayer));
        assertThat(sides.get(ONE).size()).isEqualTo(1);
        assertThat(sides.get(TWO).size()).isEqualTo(1);
    }

    @Test
    
    // testing the board for two players
    void boardShouldHaveTwoPlayers() {
        Board board = Board.create();
        Board.Players players = board.getPlayers();
        assertThat(players.player1().num()).isEqualTo(ONE);
        assertThat(players.player2().num()).isEqualTo(TWO);
    }

    @Test
    
    // testing between pit for player one and for player two
    void housesShouldHaveMutualOpposites() {
        Board board = Board.create();
        Board.Players players = board.getPlayers();
        List<Pit> pitOne = players.player1().pits();
        List<Pit> pitTwo = players.player2().pits();
        assertThat(pitOne.get(0).getOpposite().get()).isEqualTo(pitTwo.get(5));
        assertThat(pitOne.get(1).getOpposite().get()).isEqualTo(pitTwo.get(4));
        assertThat(pitOne.get(2).getOpposite().get()).isEqualTo(pitTwo.get(3));
        assertThat(pitOne.get(3).getOpposite().get()).isEqualTo(pitTwo.get(2));
        assertThat(pitOne.get(4).getOpposite().get()).isEqualTo(pitTwo.get(1));
        assertThat(pitOne.get(5).getOpposite().get()).isEqualTo(pitTwo.get(0));
        assertThat(pitTwo.get(0).getOpposite().get()).isEqualTo(pitOne.get(5));
        assertThat(pitTwo.get(1).getOpposite().get()).isEqualTo(pitOne.get(4));
        assertThat(pitTwo.get(2).getOpposite().get()).isEqualTo(pitOne.get(3));
        assertThat(pitTwo.get(3).getOpposite().get()).isEqualTo(pitOne.get(2));
        assertThat(pitTwo.get(4).getOpposite().get()).isEqualTo(pitOne.get(1));
        assertThat(pitTwo.get(5).getOpposite().get()).isEqualTo(pitOne.get(0));
    }

    @Test
    
    // testing a rotation from the board
    void allPitsShouldFormACycle() {
        Board board = Board.create();
        Pit first = board.getPits().get(0);
        Pit pit = first;

        Set<Pit> all = new HashSet<>();
        all.add(pit);

        for (int i=0; i<14; i++) {
            pit = (Pit) pit.next();
            all.add(pit);
        }

        assertThat(pit).isEqualTo(first);
        assertThat(all.size()).isEqualTo(14);
    }

}
